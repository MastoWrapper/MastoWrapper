# MastoWrapper
## Mastodon Python Wrapper
MastoWrapper is a Mastodon API wrapper dedicated to providing a simplistic but powerful integration to allow for application development for the decentralized social media platform.

_**Streaming**_
> The MastoWrapper supports streaming to functions which are called after decorators.